from django.urls import path
from apps.clientes.views import home

urlpatterns = [
    path('', home, name= 'home'),
]
