from django.urls import path
from apps.ventas.views import home

urlpatterns = [
    path('', home, name= 'home'),
]

